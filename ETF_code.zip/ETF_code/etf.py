
#%% 
# Documentation for this script:
# https://www.morningstar.com.au/ETFs/PerformanceTable

'''
 - This script, using the url from line 2, seeks to collate all available ETF's by 
scraping information from the Morningstar Website
 - It will perform this action through:
    (1) Scrapping the morningstar website
    (2) Arranging the ETF's in descending order for each of the following 
        requirements:
        (a) YTD return %
        (b) 6 mth return %
        (c) 1 yr return %
        (d) 3 yr return %
    (3) Isolate the top 10 best returning ETF's based on the criteria from (2)
    (4) Isolate the EFT's that are represented in the criteria from (2a - 2d)
    (5) Filter top results based on whether the ETF is trading at a premium/
         discount to NAV
    (6) Print DPS / NAV / Current Price and Dividend yield of each ETF
'''
### (A)
## (1) Scrapping the morningstar website
# Importing appropriate packages
import pandas as pd
import requests
from bs4 import BeautifulSoup
#%%
### (B)
#Defining the Morningstar URL
url = 'https://www.morningstar.com.au/ETFs/PerformanceTable'

def MorningStar(url):
    # Saving the url with pandas to a df called 'df'
    # dtEtfTable df stores the desired information 
    df = pd.read_html(url)
    dtEtfTable = df[0]

    # Collecting the df and saving it as an excel file
    dtEtfTable.to_excel('etfs.xlsx')

def screener(url_name):
    stock_ticker_mi = url_name
    url_root_mi = 'http://www.marketindex.com.au/asx/'
    url_marketIndex = url_root_mi + stock_ticker_mi

    core_ticker = url_name
    url_core_1 = 'https://finance.yahoo.com/quote/'
    url_core_2 = '.AX?p='
    url_core_3 = '.AX&.tsrc=fin-srch'
    url_yfinance = url_core_1 + core_ticker + url_core_2 + core_ticker + url_core_3

    # Incorporate this into the main
    # FEMX works

    page_marketIndex = requests.get(url_marketIndex)
    soup_marketIndex = BeautifulSoup(page_marketIndex.content, 'html.parser')

    page_yfinance = requests.get(url_yfinance)
    soup_yfinance = BeautifulSoup(page_yfinance.content, 'html.parser')

    # finding dps
    table_dps = soup_marketIndex.find_all('table')[3]
    dps_tags = table_dps.find_all('td', class_ = 'text-right')

    # finding nav
    table_nav = soup_yfinance.find_all('table')[1]
    nav_tags = table_nav.find_all('td', class_ = 'Ta(end) Fw(600) Lh(14px)')

    try:
        # current dps
        dps = float(dps_tags[4].text.replace('$',''))
        
        # current nav
        nav = float(nav_tags[1].text)  

        # current price  
        price = float(soup_yfinance.find('span', class_ = 'Trsdu(0.3s) Fw(b) Fz(36px) Mb(-4px) D(ib)').text)

        # dividend yield
        div_yield = round((dps / price) * 100, 3)
    except:
        dps = 0.0       # setting dps to 0
        nav = 0.0       # setting nav to 0
        price = 0.0     # setting price to 0
        div_yield = 0.0 # setting dividend yield to 0

    print("*************************************************************** \n")
    print("Printing DPS, NAV, Current Price and the Dividend Yield for:", url_name, "\n")
    print("DPS: $", dps)
    print("NAV: $", nav)
    print("Current Price: $", price)
    print("Dividend Yield: ", div_yield, "% \n")
    

    # nav price test
    if nav > 0 and price:
        try:
            if price > nav:
                print('Do not buy: price > nav \n')
                print("*************************************************************** \n")
            elif price < nav:
                print('Buy: price < nav \n')
                print("*************************************************************** \n")
            else:
                print('Buy: price == nav \n')
                print("*************************************************************** \n")
        except:
            print("Could not determine nav and price relationship \n")
            print("*************************************************************** \n")
    else:
        print("Unable to determine price / nav relationship. \n")
        print("*************************************************************** \n")

MorningStar(url)
#%%
### (D)
# Saving every df from R into a df in python and extracting the 
# stock tickers
oneYearDF = pd.read_excel(r'oneYearDF.xlsx').ETF_Ticker
sixMonthDF = pd.read_excel(r'sixMonthDF.xlsx').ETF_Ticker
threeYearDF = pd.read_excel(r'threeYearDF.xlsx').ETF_Ticker
ytdDF = pd.read_excel(r'ytdDF.xlsx').ETF_Ticker
ytdSixDF = pd.read_excel(r'ytdSixDF.xlsx').ETF_Ticker
ytdSixOneDF = pd.read_excel(r'ytdSixOneDF.xlsx').ETF_Ticker
ytdSixOneThreeDF = pd.read_excel(r'ytdSixOneThreeDF.xlsx').ETF_Ticker 

# (6) Printing recommendation on what ETF to
print(
    "Which output do you want to see? \n"
    "Press 1 for Year to Date (YTD) DF \n"
    "Press 2 for Six Month DF \n"
    "Press 3 for One Year DF \n"
    "Press 4 for Three Year DF \n"
    "Press 5 for Year to Date (YTD) and Six Month DF \n"
    "Press 6 for Year to Date (YTD), Six Month and One Year DF \n"
    "Press 7 for Year to Date (YTD), Six Month One Year and Three Years DF \n"
)

selection = int(input())

if selection == 1:
    print("YOU SELECTED OPTION: ", selection, "\n")
    for i in ytdDF:
        try:
            screener(i) 
        except:
            print("Fail loading: ", i)
            continue

elif selection == 2:
    print("YOU SELECTED OPTION: ", selection, "\n")
    for i in sixMonthDF:
        try:
            screener(i) 
        except:
            print("Fail loading: ", i)
            continue

elif selection == 3:
    print("YOU SELECTED OPTION: ", selection, "\n")
    for i in oneYearDF:
        try:
            screener(i) 
        except:
            print("Fail loading: ", i)
            continue

elif selection == 4:
    print("YOU SELECTED OPTION: ", selection, "\n")
    for i in threeYearDF:
        try:
            screener(i) 
        except:
            print("Fail loading: ", i)
            continue

elif selection == 5:
    print("YOU SELECTED OPTION: ", selection, "\n")
    for i in ytdSixDF:
        try:
            screener(i) 
        except:
            print("Fail loading: ", i)
            continue

elif selection == 6:
    print("YOU SELECTED OPTION: ", selection, "\n")
    for i in ytdSixOneDF:
        try:
            screener(i) 
        except:
            print("Fail loading: ", i)
            continue

elif selection == 7:
    print("YOU SELECTED OPTION: ", selection, "\n")
    for i in ytdSixOneThreeDF:
        try:
            screener(i) 
        except:
            print("Fail loading: ", i)
            continue 

else:
    print("Wrong input selected")     